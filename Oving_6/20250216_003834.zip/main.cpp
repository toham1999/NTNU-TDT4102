#include "std_lib_facilities.h"
#include "CourseCatalog.h"
#include "FileUtils.h"
#include "bouncingBall.h"

int main()
{

	bouncingBall();
	/* 
	std::string task1Filename = "task1.txt";
	writeUserInputToFile(task1Filename);
	addLineNumbers(task1Filename);

	//testCourseCatalog();

	CourseCatalog cc;
	cout << cc;
	cc.loadFromFile("wow.txt");
	cout << cc;
	
	std::filesystem::path config_file{"konfigurasjon.txt"};
	std::ifstream is{config_file};
	Config slow;
	is >> slow;
	*/
	return 0;
}