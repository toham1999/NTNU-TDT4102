#include "CourseCatalog.h"

// BEGIN: 3a

// END: 3a

// BEGIN: 3b

// END: 3b

// BEGIN: 3c

// END: 3c

// BEGIN: 3d

// END: 3d

// BEGIN: 3e

// END: 3e

// BEGIN: 3g

// END: 3g

// BEGIN: 3h

// END: 3h