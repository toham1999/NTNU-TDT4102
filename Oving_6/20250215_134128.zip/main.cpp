#include "std_lib_facilities.h"
#include "CourseCatalog.h"
#include "FileUtils.h"
#include "bouncingBall.h"

int main()
{
	/* std::string task1Filename = "task1.txt";
	writeUserInputToFile(task1Filename);
	addLineNumbers(task1Filename);
	*/


	testCourseCatalog();
	return 0;
}