#include "CourseCatalog.h"

// BEGIN: 3a
void CourseCatalog::addCourse(const string& key, const string& value)
{
    courses.insert({key,value});
}
// END: 3a

// BEGIN: 3b
void CourseCatalog::removeCourse(const string& key)
{
    courses.erase(key);
}
// END: 3b

// BEGIN: 3c
string CourseCatalog::getCourse(const string& key) const
{
    
    return courses.at(key);
}
// END: 3c

// BEGIN: 3d
ostream& operator<<(ostream& os, const CourseCatalog& cc) 
{
    for (const auto& course : cc.courses) {
        os << course.first << ":" << course.second << endl;
    }
    return os;
}
// END: 3d

// BEGIN: 3e
void testCourseCatalog()
{
    CourseCatalog cc;
	cc.addCourse("TDT4110","Informasjonsteknologi grunnkurs");
    cc.addCourse("TDT4102","Prosedyre- og objektorientert programmering");
    cc.addCourse("TMA4100","Matematikk 1");
    cout << cc << endl;
    cc.saveToFile("wow.txt");
}
// END: 3e

// BEGIN: 3g
void CourseCatalog::saveToFile(const string& filename) const
{
    std::ofstream outputStream{filename};

    if (!outputStream) 
	{ // Sjekker om strømmen ble åpnet
		std::cout << "Could not open file" << std::endl;
	}
    outputStream << *this;
}
// END: 3g

// BEGIN: 3h
void CourseCatalog::loadFromFile(const string& filename)
{
    std::ifstream inputStream{filename};
}
// END: 3h