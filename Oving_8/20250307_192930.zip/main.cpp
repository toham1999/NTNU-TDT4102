#include "Person.h"
#include "Meeting.h"
#include "MeetingWindow.h"
#include <iostream>

int main()
{
	/*
	Car c(0);
	Person p("Tor Hammer", "tghammer@stud.ntnu.no",std::make_unique<Car>(c));
	std::cout << p;
	p.setEmail("tor.ravatn@gmail.com");
	std::cout << p.getEmail() << std::endl;
	std::cout << p.hasAvailableSeats() << std::endl;
	std::cout << p;
	*/
	
	
	return 0;
}