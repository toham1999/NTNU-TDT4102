#include "Person.h"
#include "Meeting.h"
#include "MeetingWindow.h"
#include <iostream>

int main()
{
	Car c(0);
	Person personTor("Tor Hammer", "tghammer@stud.ntnu.no",std::make_unique<Car>(c));
	
	std::shared_ptr<Person> leader = std::make_shared<Person>("Gunnar Ravatn", "tor.ravatn@gmail.com");  
	Meeting meet(11, 11, 12, Campus::trh, "X-TEAM", leader);
	meet.addParticipant(std::make_shared<Person> (personTor));
	std::cout << meet << std::endl;
	return 0;
}