#pragma once

// BEGIN: 5a
// Deklarer funksjonen randomWithLimits som tar inn et 
// heltall som nedre grense som første argument og et heltall som øvre grense som andre argument. 
int randomWithLimits(int nedreLim, int ovreLim);
// END: 5a