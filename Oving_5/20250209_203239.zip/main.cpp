#include "Card.h"
#include "CardDeck.h"
#include "std_lib_facilities.h"
#include "Blackjack.h"


int main()
{

	Blackjack bj;
	bj.playGame();
	return 0;
}