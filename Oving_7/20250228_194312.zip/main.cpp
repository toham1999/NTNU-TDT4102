#include <iostream>
#include "DynamicMemory.h"
#include "Matrix.h"
#include "Dummy.h"

int main() { 
	
	testMatrix();

	
	//dummyTest();
	return 0;
}