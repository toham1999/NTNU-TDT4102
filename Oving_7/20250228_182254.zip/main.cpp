#include <iostream>
#include "DynamicMemory.h"
#include "Matrix.h"
#include "Dummy.h"

int main() { 
	
	int row = 5;
	int col = 4;

	 
	std::cout << "Testing rectangle matrix constructor:" << std::endl;
    Matrix A(row,col);
	A.set(0,0,10);
	A.set(0,3,15);
	std::cout << A << std::endl;

	std::cout << "Testing copy matrix constructor:" << std::endl;
    Matrix Co{A};
	std::cout << Co << std::endl;

	std::cout << "Testing identity matrix constructor:" << std::endl;
	Matrix ID(row);
	std::cout << ID << std::endl;

	std::cout << "Testing = matrix symbol:" << std::endl;
	Matrix ID_copy(3,5);
	ID_copy = ID;
	std::cout << ID_copy << std::endl;
	
	//dummyTest();
	return 0;
}