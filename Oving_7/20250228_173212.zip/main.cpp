#include <iostream>
#include "DynamicMemory.h"
#include "Matrix.h"
#include "Dummy.h"

int main() {
	/*
	int row = 5;
	int col = 10;

	
	std::cout << "Testing rectangle matrix constructor:" << std::endl;
    Matrix A(row,col);
	A.set(0,0,10);
	std::cout << A << std::endl;

	std::cout << "Testing identity matrix constructor:" << std::endl;
	Matrix ID(row);
	std::cout << ID << std::endl;
	*/
	dummyTest();
	return 0;
}