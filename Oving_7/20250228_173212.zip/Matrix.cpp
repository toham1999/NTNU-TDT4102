#include "Matrix.h"
#include <cassert>

// BEGIN: 2b
Matrix::Matrix(int nRows, int nColumns)
{
    assert(nRows > 0 && nColumns > 0 && "Matrix dimensions must be positive!");
    rows = nRows;
    columns = nColumns;

    matrix = new double*[nRows] {};
    for (int i=0;i<nRows;i++)
    {
        matrix[i] = new double[nColumns] {};
    }
}

Matrix::Matrix(int nRows): Matrix(nRows, nRows) 
{
    for (int j=0;j<nRows;j++) // Add the identity matrix ones
    {
        matrix[j][j] = 1;
    }
}

Matrix::~Matrix()
{
    for (int i=0;i<rows;i++)
    {
        delete[] matrix[i];
        matrix[i] = nullptr;
    }
    delete[] matrix;
    matrix = nullptr;
}
// END: 2b

// BEGIN: 2c
double Matrix::get(int row, int col) const
{
    return matrix[row][col];
}
void Matrix::set(int row, int col, double value)
{
    matrix[row][col] = value;
}
// END: 2c

// Her kan du gjøre 2d (frivillig):
double* Matrix::operator[](int placement) const
{
    return matrix[placement];
}

// BEGIN: 2f
#include <iomanip>
std::ostream& operator<<(std::ostream& os, const Matrix& rhs)
{
    int nrOfRows = rhs.getRows(); 
    int nrOfColumns = rhs.getColumns();
    for (int j=0;j<nrOfRows;j++)
    {
        for (int i=0;i<nrOfColumns;i++)
        {
            os << std::setw(5) << rhs.get(j,i);
        }
        os << std::endl;
    }
    return os;
}
// END: 2f


// BEGIN: 4a

// END: 4a

// BEGIN: 4b

// END: 4b


// BEGIN: 5a

// END: 5a

// BEGIN: 5b

// END: 5b


void testMatrix() {
    // Her kan du teste løsningen din (oppgave 5c):
}

// Her kan du gjøre 5d (frivillig):