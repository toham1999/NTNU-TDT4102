#include <iostream>

void messageFromOtherFile() {
    std::cout << "Hello from the other side!\n";
    return;
}