#include "std_lib_facilities.h"
#include "test.h"
#include "mastermind.h"

int main()
{	/*
	testCallByValue();
	testCallByReference();
	int heltall1 = 10;
	int heltall2 = 50;
	cout << "Heltall 1: " << heltall1 << ", Heltall 2: "
	<< heltall2 << endl;
	swapNumbers(heltall1,heltall2);
	cout << "Heltall 1: " << heltall1 << ", Heltall 2: "
	<< heltall2 << endl;
	
	Student studd;
	printStudent(studd);
	cout << isInProgram(studd,"MTNANO") << endl;
	
	

	testString();
	cout << "String: " << readInputToString(10,'A','J');
	// Her kan du teste koden og funksjonene dine, 
	// Ingenting som skrives her blir automatisk rettet, du tester her for din egen del
	
	cout << "Number of times: " << countChar("wertgvbnjjhghgvbnjhjbvghbkhjg",'f') << endl;
	
	string string1 = "AEDF";
	string string2 = "ADDE";
	cout << "Correct places: " << checkCharactersAndPosition(string1,string2);
	cout << "Letters same: " << checkCharacters(string1,string2);
	//testString();
	*/
	playMastermind();
	return 0;
}
